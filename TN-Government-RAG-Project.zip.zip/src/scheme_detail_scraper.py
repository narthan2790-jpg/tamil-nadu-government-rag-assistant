
import requests
import json
import time
from pathlib import Path
from bs4 import BeautifulSoup
from urllib.parse import urljoin

# Existing collected links
INPUT_FILE = Path("documents/policies/scheme_links.json")

# Output folders
OUTPUT_DIR = Path("documents/policies/schemes")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

JSON_OUTPUT = Path("processed/government_schemes.json")
JSON_OUTPUT.parent.mkdir(parents=True, exist_ok=True)

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
}

session = requests.Session()
session.headers.update(HEADERS)


def extract_page(url):

    response = session.get(url, timeout=60)
    response.raise_for_status()

    if not response.encoding or response.encoding.lower() == "iso-8859-1":
        response.encoding = response.apparent_encoding

    soup = BeautifulSoup(response.text, "html.parser")

    title = soup.title.get_text(" ", strip=True) if soup.title else ""

    # Remove navigation and non-content elements
    for tag in soup([
        "script", "style", "noscript",
        "header", "footer", "nav", "audio"
    ]):
        tag.decompose()

    # Prefer the main content area
    content = (
        soup.find("main")
        or soup.find("article")
        or soup.find(id="content")
        or soup.find(class_="content")
        or soup.body
        or soup
    )

    text = content.get_text(separator="\n", strip=True)

    return title, text


def main():

    if not INPUT_FILE.exists():
        print("ERROR: scheme_links.json not found!")
        return

    links = json.loads(INPUT_FILE.read_text(encoding="utf-8"))

    results = []

    print("Total scheme pages:", len(links))

    for number, item in enumerate(links, 1):

        name = item.get("name", "")
        url = urljoin(
            "https://www.tn.gov.in/",
            item.get("url", "")
        )

        print(f"\n[{number}/{len(links)}] Reading: {name}")
        print("URL:", url)

        try:
            title, text = extract_page(url)

            if len(text.strip()) < 100:
                print("WARNING: Very little page content found.")

            record = {
                "scheme_name": name,
                "page_title": title,
                "url": url,
                "text": text,
                "status": "success"
            }

            results.append(record)

            # Save individual scheme
            filename = OUTPUT_DIR / f"scheme_{number:03d}.txt"

            filename.write_text(
                f"Scheme: {name}\n"
                f"Title: {title}\n"
                f"URL: {url}\n\n"
                f"{text}",
                encoding="utf-8"
            )

            print("SUCCESS: Saved", filename)

        except Exception as error:

            print("FAILED:", error)

            results.append({
                "scheme_name": name,
                "url": url,
                "text": "",
                "status": "failed",
                "error": str(error)
            })

        # Avoid sending rapid requests
        time.sleep(1)

        # Save progress after every page
        JSON_OUTPUT.write_text(
            json.dumps(results, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

    successful = sum(
        1 for item in results
        if item["status"] == "success"
    )

    print("\n------------------------------")
    print("SCRAPING COMPLETED")
    print("Total links:", len(links))
    print("Successful:", successful)
    print("Failed:", len(results) - successful)
    print("JSON saved:", JSON_OUTPUT)
    print("Individual pages:", OUTPUT_DIR)
    print("------------------------------")


if __name__ == "__main__":
    main()
