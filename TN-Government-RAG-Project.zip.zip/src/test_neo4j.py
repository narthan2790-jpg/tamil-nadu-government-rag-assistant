
import traceback
from neo4j.debug import watch
from src.config import get_driver, URI, USERNAME, DATABASE

print("Neo4j URI:", URI)
print("Username:", USERNAME)
print("Database:", DATABASE)

driver = get_driver()

try:
    print("\nStarting detailed connection test...")

    with watch("neo4j"):
        driver.verify_connectivity()

        print("\nSUCCESS: Connected to Neo4j Aura!")

        with driver.session(database=DATABASE) as session:
            result = session.run("RETURN 1 AS test")
            print("Database test:", result.single()["test"])

except Exception as error:
    print("\nDETAILED ERROR:")
    print(repr(error))
    traceback.print_exc()

finally:
    driver.close()
