
import os
from pathlib import Path
from dotenv import load_dotenv
from neo4j import GraphDatabase

# Load environment variables from project root
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env", override=True)

# Neo4j credentials
URI = os.getenv("NEO4J_URI")
USERNAME = os.getenv("NEO4J_USERNAME")
PASSWORD = os.getenv("NEO4J_PASSWORD")
DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")

def get_driver():
    if not all([URI, USERNAME, PASSWORD]):
        raise ValueError("Neo4j credentials missing in .env file")

    return GraphDatabase.driver(
        URI,
        auth=(USERNAME, PASSWORD)
    )
