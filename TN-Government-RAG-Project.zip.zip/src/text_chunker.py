
import re
import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = BASE_DIR / "processed" / "government_orders.txt"
OUTPUT_FILE = BASE_DIR / "processed" / "government_orders_chunks.json"

CHUNK_SIZE = 800
CHUNK_OVERLAP = 150


def clean_text(text):
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def create_chunks(text):

    words = text.split()

    chunks = []
    start = 0
    chunk_number = 1

    while start < len(words):

        end = min(start + CHUNK_SIZE, len(words))

        chunk_text = " ".join(words[start:end])

        chunks.append({
            "chunk_id": chunk_number,
            "text": chunk_text
        })

        chunk_number += 1

        if end == len(words):
            break

        start = end - CHUNK_OVERLAP

    return chunks


def main():

    if not INPUT_FILE.exists():
        print("Input text file not found!")
        return

    print("Reading extracted government document...")

    text = INPUT_FILE.read_text(encoding="utf-8")

    cleaned_text = clean_text(text)

    chunks = create_chunks(cleaned_text)

    OUTPUT_FILE.write_text(
        json.dumps(
            chunks,
            ensure_ascii=False,
            indent=4
        ),
        encoding="utf-8"
    )

    print("\nChunking completed successfully!")
    print("Total chunks:", len(chunks))
    print("Saved to:", OUTPUT_FILE)


if __name__ == "__main__":
    main()
