
import requests
import json
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from pathlib import Path

URL = "https://www.tn.gov.in/scheme_list.php?dep_id=Mg=="

headers = {"User-Agent": "Mozilla/5.0"}

print("Collecting scheme-related links...")

response = requests.get(URL, headers=headers, timeout=60)
response.raise_for_status()

soup = BeautifulSoup(response.text, "html.parser")

links = []
seen = set()

for link in soup.find_all("a", href=True):

    name = link.get_text(" ", strip=True)
    href = link["href"].strip()

    if "scheme" in (name + " " + href).lower():

        full_url = urljoin(URL, href)

        if full_url not in seen:
            seen.add(full_url)

            links.append({
                "name": name,
                "url": full_url
            })

# Save all links
output = Path("documents/policies")
output.mkdir(parents=True, exist_ok=True)

file_path = output / "scheme_links.json"

file_path.write_text(
    json.dumps(links, ensure_ascii=False, indent=4),
    encoding="utf-8"
)

print("\nTOTAL UNIQUE LINKS:", len(links))

for i, item in enumerate(links, 1):
    print(f"\n{i}. {item['name']}")
    print("   ", item["url"])

print("\nSUCCESS: Links saved to:", file_path)
