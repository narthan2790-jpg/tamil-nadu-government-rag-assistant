
from pathlib import Path
import pytesseract

# Tesseract installation path
tesseract_path = Path(
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)

# Project tessdata folder
tessdata_path = Path.cwd() / "tessdata"

print("Tesseract exists:", tesseract_path.exists())
print("Tessdata exists:", tessdata_path.exists())

pytesseract.pytesseract.tesseract_cmd = str(tesseract_path)

# Check available languages
languages = pytesseract.get_languages(
    config=f'--tessdata-dir "{tessdata_path}"'
)

print("Available languages:", languages)
