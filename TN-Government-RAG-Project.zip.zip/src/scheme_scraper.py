
import requests
from bs4 import BeautifulSoup
from pathlib import Path

URL = "https://www.tn.gov.in/scheme_list.php?dep_id=Mg=="

headers = {
    "User-Agent": "Mozilla/5.0"
}

print("Connecting to Tamil Nadu Government website...")

try:
    response = requests.get(
        URL,
        headers=headers,
        timeout=60
    )

    print("HTTP Status:", response.status_code)
    response.raise_for_status()

    soup = BeautifulSoup(response.text, "html.parser")

    title = soup.title.get_text(strip=True) if soup.title else "No title"

    print("Website title:", title)

    # Extract visible text
    page_text = soup.get_text(separator="\n", strip=True)

    output = Path("documents/policies")
    output.mkdir(parents=True, exist_ok=True)

    file_path = output / "government_schemes.txt"
    file_path.write_text(page_text, encoding="utf-8")

    # Extract website links
    links = []

    for link in soup.find_all("a", href=True):
        links.append({
            "name": link.get_text(strip=True),
            "url": link["href"]
        })

    print("Text characters:", len(page_text))
    print("Links found:", len(links))

    for item in links[:20]:
        print(item)

    print("\nSUCCESS: Website content saved!")
    print("Saved:", file_path)

except Exception as error:
    print("ERROR:", error)
