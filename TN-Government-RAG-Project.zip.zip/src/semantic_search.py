
import os
from dotenv import load_dotenv
from neo4j import GraphDatabase
from sentence_transformers import SentenceTransformer

# Load environment variables
load_dotenv()

NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USERNAME = os.getenv("NEO4J_USERNAME")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD")
NEO4J_DATABASE = os.getenv("NEO4J_DATABASE", "neo4j")

INDEX_NAME = "government_chunks_index"
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

print("Loading multilingual embedding model...")
model = SentenceTransformer(MODEL_NAME)

driver = GraphDatabase.driver(
    NEO4J_URI,
    auth=(NEO4J_USERNAME, NEO4J_PASSWORD)
)

def search_government_documents(question, top_k=3):

    # Convert question into a 384-dimensional embedding
    question_embedding = model.encode(
        question,
        normalize_embeddings=True
    ).tolist()

    query = """
    CALL db.index.vector.queryNodes(
        $index_name,
        $top_k,
        $embedding
    )
    YIELD node, score

    RETURN
        node.chunk_id AS chunk_id,
        node.text AS text,
        score

    ORDER BY score DESC
    """

    with driver.session(database=NEO4J_DATABASE) as session:

        results = session.run(
            query,
            index_name=INDEX_NAME,
            top_k=top_k,
            embedding=question_embedding
        )

        records = list(results)

    print("\nSEARCH RESULTS")
    print("=" * 60)

    if not records:
        print("No matching government documents found.")
        return

    for record in records:

        print("\nChunk ID:", record["chunk_id"])
        print("Similarity:", round(record["score"], 4))
        print("Document text:")
        print(record["text"])
        print("-" * 60)


if __name__ == "__main__":

    try:
        driver.verify_connectivity()
        print("Connected to Neo4j Aura successfully!")

        question = input("\nEnter your government-related question: ")

        search_government_documents(question)

    except Exception as error:
        print("\nERROR:", error)

    finally:
        driver.close()
