
import os
from pathlib import Path
from io import BytesIO

import fitz
import pytesseract
from PIL import Image

# =====================================
# 1. PROJECT DIRECTORIES
# =====================================

BASE_DIR = Path(__file__).resolve().parent.parent

DOCUMENTS_DIR = BASE_DIR / "documents"
PROCESSED_DIR = BASE_DIR / "processed"
TESSDATA_DIR = BASE_DIR / "tessdata"

# =====================================
# 2. TESSERACT CONFIGURATION
# =====================================

TESSERACT_PATH = (
    r"C:\Program Files\Tesseract-OCR\tesseract.exe"
)

pytesseract.pytesseract.tesseract_cmd = TESSERACT_PATH

os.environ.pop("TESSDATA_PREFIX", None)

OCR_LANGUAGES = "eng+tam"

OCR_CONFIG = (
    f'--tessdata-dir {TESSDATA_DIR} '
    '--oem 1 --psm 3'
)
print("Tesseract path:", TESSERACT_PATH)
print("Tessdata directory:", TESSDATA_DIR)
print("Tessdata exists:", TESSDATA_DIR.exists())

print(
    "Available OCR languages:",
    pytesseract.get_languages(
        config=f'--tessdata-dir {TESSDATA_DIR}'
    )
)

MIN_TEXT_CHARS = 30

# =====================================
# 3. EXTRACT PDF TEXT
# =====================================

def extract_pdf_text(pdf_path):

    pages_text = []

    pdf = fitz.open(str(pdf_path))

    try:
        print(f"\nReading: {pdf_path.name}")

        for page_number, page in enumerate(pdf, start=1):

            text = page.get_text("text") or ""

            if len(text.strip()) < MIN_TEXT_CHARS:

                print(
                    f"Page {page_number}: "
                    "Using Tamil + English OCR..."
                )

                pix = page.get_pixmap(
                    matrix=fitz.Matrix(300 / 72, 300 / 72),
                    alpha=False
                )

                image = Image.open(
                    BytesIO(pix.tobytes("png"))
                )

                text = pytesseract.image_to_string(
                    image,
                    lang=OCR_LANGUAGES,
                    config=OCR_CONFIG
                )

            else:
                print(
                    f"Page {page_number}: "
                    "Normal text extracted."
                )

            pages_text.append({
                "page": page_number,
                "text": text
            })

    finally:
        pdf.close()

    return pages_text


# =====================================
# 4. PROCESS ALL PDF FILES
# =====================================

def process_all_pdfs():

    PROCESSED_DIR.mkdir(
        parents=True,
        exist_ok=True
    )

    pdf_files = list(
        DOCUMENTS_DIR.rglob("*.pdf")
    )

    print(f"\nFound {len(pdf_files)} PDF files.")

    for pdf_file in pdf_files:

        try:

            pages = extract_pdf_text(pdf_file)

            output_file = (
                PROCESSED_DIR /
                f"{pdf_file.stem}.txt"
            )

            with open(
                output_file,
                "w",
                encoding="utf-8"
            ) as file:

                for page in pages:

                    file.write(
                        f"\n--- Page {page['page']} ---\n"
                    )

                    file.write(
                        page["text"] + "\n"
                    )

            print(
                f"\nSUCCESS: Processed {pdf_file.name}"
            )

            print(f"Saved to: {output_file}")

        except Exception as error:

            print(
                f"\nERROR processing {pdf_file.name}: "
                f"{error}"
            )


# =====================================
# 5. RUN PROGRAM
# =====================================

if __name__ == "__main__":
    process_all_pdfs()
