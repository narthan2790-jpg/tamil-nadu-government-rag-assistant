
import json
import os
from pathlib import Path

from dotenv import load_dotenv
from neo4j import GraphDatabase

# PROJECT PATHS
BASE_DIR = Path(__file__).resolve().parent.parent
JSON_FILE = BASE_DIR / "processed" / "government_orders_embeddings.json"

# LOAD ENVIRONMENT
load_dotenv(BASE_DIR / ".env", override=True)

URI = os.getenv("NEO4J_URI")
USERNAME = os.getenv("NEO4J_USERNAME")
PASSWORD = os.getenv("NEO4J_PASSWORD")
DATABASE = os.getenv("NEO4J_DATABASE")

if not all([URI, USERNAME, PASSWORD, DATABASE]):
    raise ValueError("Missing Neo4j credentials in .env")

# READ EMBEDDINGS
print("Reading embedding file...")

with open(JSON_FILE, "r", encoding="utf-8") as file:
    records = json.load(file)

if not records:
    raise ValueError("No embedding records found.")

# VALIDATE DATA
for record in records:
    embedding = record.get("embedding")

    if not isinstance(embedding, list) or len(embedding) != 384:
        raise ValueError(
            f"Invalid embedding in chunk {record.get('chunk_id')}. "
            "Expected 384 dimensions."
        )

    if not record.get("text"):
        raise ValueError("Empty text found.")

print("Total records:", len(records))
print("Embedding dimensions:", len(records[0]["embedding"]))

# CONNECT AND UPLOAD
driver = GraphDatabase.driver(
    URI,
    auth=(USERNAME, PASSWORD),
    connection_timeout=30
)

try:
    driver.verify_connectivity()
    print("Connected to Neo4j Aura!")

    with driver.session(database=DATABASE) as session:

        def upload_chunks(tx):
            result = tx.run(
                """
                UNWIND $records AS row
                MERGE (c:DocumentChunk {chunk_id: row.chunk_id})
                SET c.text = row.text,
                    c.embedding = row.embedding
                RETURN count(c) AS uploaded
                """,
                records=records
            )
            return result.single()["uploaded"]

        uploaded = session.execute_write(upload_chunks)

        print("Uploaded chunks:", uploaded)

        # CREATE VECTOR INDEX
        session.run(
            """
            CREATE VECTOR INDEX government_chunks_index IF NOT EXISTS
            FOR (c:DocumentChunk)
            ON (c.embedding)
            OPTIONS {
                indexConfig: {
                    `vector.dimensions`: 384,
                    `vector.similarity_function`: 'cosine'
                }
            }
            """
        ).consume()

        print("Vector index creation command completed.")

        # VERIFY DATABASE
        result = session.run(
            """
            MATCH (c:DocumentChunk)
            RETURN count(c) AS total_chunks
            """
        )

        print("Total chunks in Neo4j:", result.single()["total_chunks"])

    print("\nSUCCESS: Government embeddings uploaded!")

except Exception as error:
    print("\nUPLOAD FAILED")
    print(type(error).__name__, error)
    raise

finally:
    driver.close()
