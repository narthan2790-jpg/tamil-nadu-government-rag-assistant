
import json
from pathlib import Path
from sentence_transformers import SentenceTransformer

BASE_DIR = Path(__file__).resolve().parent.parent

INPUT_FILE = BASE_DIR / "processed" / "government_orders_chunks.json"
OUTPUT_FILE = BASE_DIR / "processed" / "government_orders_embeddings.json"

# Multilingual model supporting Tamil and English
MODEL_NAME = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"


def main():

    print("Loading embedding model...")

    model = SentenceTransformer(MODEL_NAME)

    with open(INPUT_FILE, "r", encoding="utf-8") as file:
        chunks = json.load(file)

    print("Generating embeddings...")

    texts = [chunk["text"] for chunk in chunks]

    embeddings = model.encode(
        texts,
        normalize_embeddings=True
    )

    results = []

    for chunk, embedding in zip(chunks, embeddings):

        results.append({
            "chunk_id": chunk["chunk_id"],
            "text": chunk["text"],
            "embedding": embedding.tolist()
        })

    with open(OUTPUT_FILE, "w", encoding="utf-8") as file:

        json.dump(
            results,
            file,
            ensure_ascii=False,
            indent=2
        )

    print("\nEmbeddings generated successfully!")
    print("Total embeddings:", len(results))
    print("Vector dimensions:", len(embeddings[0]))
    print("Saved to:", OUTPUT_FILE)


if __name__ == "__main__":
    main()
